import gameInterface.AIInterface;
import structs.FrameData;
import structs.GameData;
import structs.Key;

public class IAPrimero implements AIInterface {

	@Override
	public void close() {
		// TODO Auto-generated method stub

	}

	@Override
	public String getCharacter() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void getInformation(FrameData arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public int initialize(GameData arg0, boolean arg1) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Key input() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void processing() {
		// TODO Auto-generated method stub

	}

}
